"""Approval outcomes that write back policy.

Borrowed from Codex, `codex-rs/protocol/src/protocol.rs`, ``pub enum ReviewDecision``:

    Approved
    ApprovedExecpolicyAmendment { proposed_execpolicy_amendment }
    ApprovedForSession
    ApprovedMcpPolicyAmendment
    NetworkPolicyAmendment { network_policy_amendment }
    Denied { rejection }
    TimedOut
    Abort

The idea that transfers: a human decision is not only a yes/no on one call. It may carry an
*amendment* — a new rule — so the same question is not asked again, scoped to the session or
persisted. A governed system that re-asks the identical question forever trains its user to
click "yes" without reading, which is the opposite of governance.

Two constraints psh adds, both from the authority lattice:

* An amendment may only add ``allow`` rules. It cannot add ``forbidden`` (that is policy
  authoring, not approval) and it cannot remove anything. Because evaluation is
  forbidden → prompt → allow with first match winning (Claude Code's order), an added
  ``allow`` never overrides an existing ``forbidden`` — the amendment can widen only within the
  space the policy already left open.
* An amendment cannot grant beyond the run envelope. A session amendment lives as long as the
  envelope; a persisted one is written to the policy file and is itself an event.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Mapping, Sequence

from ..contracts import ApprovalDenied, ApprovalRequired, PolicyDenied, RunEnvelope, new_id
from .execpolicy import Decision, ExecPolicy, PrefixRule

__all__ = ["ApprovalKind", "PolicyAmendment", "ApprovalOutcome", "AmendingApprovalEngine"]


class ApprovalKind(str, Enum):
    APPROVED = "approved"
    APPROVED_FOR_SESSION = "approved_for_session"
    APPROVED_WITH_AMENDMENT = "approved_with_amendment"
    DENIED = "denied"
    TIMED_OUT = "timed_out"
    ABORT = "abort"


@dataclass(frozen=True, slots=True)
class PolicyAmendment:
    """A proposed new ``allow`` rule, attached to an approval."""

    pattern: tuple[Any, ...]
    justification: str
    persist: bool = False
    #: Examples the rule must match/not match — the self-test travels with the amendment.
    match: tuple[tuple[str, ...], ...] = ()
    not_match: tuple[tuple[str, ...], ...] = ()

    def to_rule(self, *, origin: str) -> PrefixRule:
        # Decision is fixed: an amendment can only ever ADD permission within what the
        # existing forbidden rules leave open.
        return PrefixRule(tuple(self.pattern), Decision.ALLOW, self.justification,
                          match=self.match, not_match=self.not_match, origin=origin)


@dataclass(frozen=True, slots=True)
class ApprovalOutcome:
    kind: ApprovalKind
    rejection: str = ""
    amendment: PolicyAmendment | None = None
    id: str = field(default_factory=lambda: new_id("apr"))
    at: float = field(default_factory=time.time)

    @property
    def approved(self) -> bool:
        return self.kind in (ApprovalKind.APPROVED, ApprovalKind.APPROVED_FOR_SESSION,
                             ApprovalKind.APPROVED_WITH_AMENDMENT)


Handler = Callable[[str, Mapping[str, Any]], "bool | ApprovalOutcome"]


class AmendingApprovalEngine:
    """Human-in-the-loop decisions that may amend policy. Fails closed without a handler.

    Drop-in for the v0.3 ``ApprovalEngine``: a handler returning a plain ``bool`` still works.
    A handler returning an ``ApprovalOutcome`` may additionally approve for the session or
    attach an amendment.
    """

    def __init__(self, handler: Handler | None = None, *, policy: ExecPolicy | None = None,
                 audit: Callable[..., Any] | None = None,
                 persist: Callable[[ExecPolicy], None] | None = None) -> None:
        self.handler = handler
        self.policy = policy
        self._audit = audit
        self._persist = persist
        self.requests: list[dict[str, Any]] = []
        #: Session-scoped approvals: (run_id, what) pairs already approved for the session.
        self._session_approved: set[tuple[str, str]] = set()
        self.amendments_applied = 0

    def _emit(self, event: str, **detail: Any) -> None:
        if self._audit is not None:
            self._audit(event, **detail)

    def request(self, what: str, envelope: RunEnvelope, **detail: Any) -> ApprovalOutcome:
        """Return an approval outcome or raise. Every request is recorded either way."""
        key = (envelope.run_id, what)
        if key in self._session_approved:
            self._emit("approval_cached", what=what, run_id=envelope.run_id)
            return ApprovalOutcome(ApprovalKind.APPROVED_FOR_SESSION)

        record = {"what": what, "run_id": envelope.run_id, "risk": envelope.risk.name, **detail}
        self.requests.append(record)
        self._emit("approval_requested", what=what, risk=envelope.risk.name)

        if self.handler is None:
            raise ApprovalRequired(
                f"{what} requires human approval and no approval handler is configured; "
                "failing closed")

        raw = self.handler(what, record)
        outcome = (ApprovalOutcome(ApprovalKind.APPROVED if raw else ApprovalKind.DENIED)
                   if isinstance(raw, bool) else raw)

        if not outcome.approved:
            self._emit("approval_denied", what=what, kind=outcome.kind.value)
            if outcome.kind is ApprovalKind.ABORT:
                raise ApprovalDenied(f"a human aborted the run at: {what}")
            raise ApprovalDenied(f"a human refused: {what}"
                                 + (f" — {outcome.rejection}" if outcome.rejection else ""))

        if outcome.kind is ApprovalKind.APPROVED_FOR_SESSION:
            self._session_approved.add(key)
        if outcome.amendment is not None:
            self._apply_amendment(outcome.amendment, envelope, what)

        self._emit("approval_granted", what=what, kind=outcome.kind.value,
                   amended=outcome.amendment is not None)
        return outcome

    def _apply_amendment(self, amendment: PolicyAmendment, envelope: RunEnvelope,
                         what: str) -> None:
        if self.policy is None:
            raise PolicyDenied("an amendment was proposed but no execution policy is attached")
        origin = f"amendment:{'persisted' if amendment.persist else envelope.run_id}"
        rule = amendment.to_rule(origin=origin)  # self-tests run here; a bad rule raises

        # The amendment must not override a forbidden rule. It cannot by construction
        # (evaluation order), but an amendment whose OWN examples are forbidden is a
        # confused or hostile proposal, and we refuse it outright rather than accept a rule
        # that silently never fires.
        for example in rule.match:
            existing = self.policy.evaluate(example)
            if existing.decision is Decision.FORBIDDEN:
                self._emit("amendment_refused", what=what, reason="conflicts with forbidden rule",
                           rule=rule.render())
                raise PolicyDenied(
                    f"amendment [{rule.render()}] would allow {list(example)!r}, which a "
                    f"forbidden rule refuses: {existing.justification}")

        self.policy.add_rule(rule)
        self.amendments_applied += 1
        self._emit("policy_amended", what=what, rule=rule.render(),
                   persist=amendment.persist, origin=origin, run_id=envelope.run_id)
        if amendment.persist and self._persist is not None:
            self._persist(self.policy)

    def expire_session(self, run_id: str) -> int:
        """Drop session-scoped approvals and rules when a run ends. Returns rules removed."""
        self._session_approved = {k for k in self._session_approved if k[0] != run_id}
        if self.policy is None:
            return 0
        before = len(self.policy.rules)
        self.policy.rules = [r for r in self.policy.rules
                             if r.origin != f"amendment:{run_id}"]
        removed = before - len(self.policy.rules)
        if removed:
            self._emit("session_amendments_expired", run_id=run_id, removed=removed)
        return removed
