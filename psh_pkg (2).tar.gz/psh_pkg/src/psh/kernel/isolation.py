"""Process-isolated tool execution behind a kernel-owned egress proxy.

This module raises psh's boundary from *in-process cooperation* to *process level*. It is the
direct response to my own audit's finding A1: any code inside the kernel process can call a
provider and the broker sees nothing. Both surveyed systems answer that finding the same way
— the operating system enforces the boundary — and this is the portable part of their answer.

Borrowed from Codex, with file paths:

* **Default-deny environment** — `codex-rs/core/src/exec_env.rs` ("env_clear() to ensure no
  unintended variables are leaked to the spawned process"), `hooks/src/engine/command_runner.rs`.
  A tool subprocess starts from an EMPTY environment and receives only what the run envelope
  grants. A scrub list misses the variable you did not think of; ``env_clear()`` does not.
* **Egress proxy as the network boundary** — `codex-rs/network-proxy/README.md`: a local proxy
  enforcing an allow/deny host policy, with private-range destinations refused unless
  explicitly allowlisted. `exec-server-protocol/src/network_policy.rs` has the same three-way
  Allow / Deny / Ask decision as execpolicy. Here: a kernel-owned HTTP CONNECT + plain-HTTP
  proxy on loopback; the subprocess's ``HTTP_PROXY``/``HTTPS_PROXY`` point at it; every
  decision is an event.
* **Process hardening** — `codex-rs/process-hardening/src/lib.rs` strips ``LD_PRELOAD`` /
  ``DYLD_*`` and disables core dumps pre-main. The env_clear above already excludes the
  loader variables; core-dump limits are applied via ``resource`` in the child's preexec.

What is enforced here, and what is not
--------------------------------------
Enforced and tested from inside this session:

* A tool subprocess cannot read the kernel's environment (credentials, proxy settings for
  anything else, ``PYTHONPATH``).
* A subprocess that honours proxy variables — every mainstream HTTP client does by default —
  is refused for a host outside the envelope's allowlist, and the refusal is an event.
* Private and loopback destinations are refused by default even through the proxy.
* The subprocess runs under a wall-clock limit, a memory limit and with core dumps disabled.

NOT enforced here, and stated plainly: a subprocess that opens a raw socket, or sets
``no_proxy``, bypasses the proxy. Codex closes that with Seatbelt (macOS) / bubblewrap +
seccomp (Linux) denying network to the process; Claude Code with the same two. Neither can be
installed or verified from inside this session, so ``SandboxBackend`` is an adapter interface
with a ``NoSandbox`` implementation that says so in ``describe()``. The proxy is a *policy*
layer; the OS sandbox is the *enforcement* layer, and only the first ships here.
"""

from __future__ import annotations

import ipaddress
import json
import os
import select
import socket
import socketserver
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Protocol, Sequence
from urllib.parse import urlsplit

__all__ = ["EgressProxy", "ProxyUnavailable", "HostDecision", "IsolatedRunner", "IsolatedResult",
           "SandboxBackend", "NoSandbox", "build_child_environment"]


# ------------------------------------------------------------------ host policy

@dataclass(frozen=True, slots=True)
class HostDecision:
    host: str
    port: int
    allowed: bool
    reason: str
    at: float = field(default_factory=time.time)


def _is_private(host: str) -> bool:
    """True for loopback, link-local, private and reserved addresses, resolving names.

    Codex refuses private-range destinations even when a hostname is allowlisted, because a
    hostname that resolves to 127.0.0.1 or 169.254.169.254 is how a proxy allowlist gets
    turned into an SSRF vector. Same rule here.
    """
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved \
            or ip.is_multicast or ip.is_unspecified
    except ValueError:
        pass
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False  # unresolvable: not private, and the connect will fail on its own
    for info in infos:
        addr = info[4][0]
        try:
            ip = ipaddress.ip_address(addr.split("%")[0])
        except ValueError:
            continue
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return True
    return False


class _HostPolicy:
    def __init__(self, allowed_hosts: Iterable[str], *, allow_private: bool = False,
                 audit: Callable[..., Any] | None = None, run_id: str = "") -> None:
        import fnmatch

        self._patterns = tuple(h.lower() for h in allowed_hosts)
        self._fn = fnmatch.fnmatch
        self.allow_private = allow_private
        self._audit = audit
        self.run_id = run_id
        self.decisions: list[HostDecision] = []
        self._lock = threading.Lock()

    def decide(self, host: str, port: int) -> HostDecision:
        h = host.lower().rstrip(".")
        if not self._patterns:
            d = HostDecision(h, port, False, "no network destinations are allowed for this run")
        elif not any(self._fn(h, p) for p in self._patterns):
            d = HostDecision(h, port, False, f"{h} is not in the run's allowed hosts")
        elif not self.allow_private and _is_private(h):
            d = HostDecision(h, port, False,
                             f"{h} resolves to a private/loopback address; refused even though "
                             "allowlisted (SSRF guard)")
        else:
            d = HostDecision(h, port, True, "allowlisted")
        with self._lock:
            self.decisions.append(d)
        if self._audit is not None:
            self._audit("egress_proxy_decision", host=h, port=port, allowed=d.allowed,
                        reason=d.reason[:120], run_id=self.run_id)
        return d


# ------------------------------------------------------------------- the proxy

class _ProxyHandler(BaseHTTPRequestHandler):
    """HTTP CONNECT tunnelling plus plain absolute-URI HTTP forwarding."""

    protocol_version = "HTTP/1.1"
    policy: _HostPolicy  # set on the server class

    def log_message(self, *_: Any) -> None:  # quiet; decisions are events, not stderr
        pass

    def _refuse(self, decision: HostDecision) -> None:
        body = json.dumps({"refused": True, "host": decision.host, "reason": decision.reason}
                          ).encode()
        self.send_response(403, "Forbidden by egress policy")
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        self.close_connection = True

    def do_CONNECT(self) -> None:  # noqa: N802
        host, _, port = self.path.rpartition(":")
        port_i = int(port or 443)
        decision = self.server.policy.decide(host, port_i)  # type: ignore[attr-defined]
        if not decision.allowed:
            self._refuse(decision)
            return
        try:
            upstream = socket.create_connection((host, port_i), timeout=15)
        except OSError as exc:
            self.send_error(502, f"upstream connect failed: {exc}")
            return
        self.send_response(200, "Connection Established")
        self.end_headers()
        self._pipe(self.connection, upstream)
        self.close_connection = True

    def _forward(self) -> None:
        parts = urlsplit(self.path)
        if not parts.hostname:
            self.send_error(400, "proxy requires an absolute URI")
            return
        port = parts.port or 80
        decision = self.server.policy.decide(parts.hostname, port)  # type: ignore[attr-defined]
        if not decision.allowed:
            self._refuse(decision)
            return
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else b""
        try:
            upstream = socket.create_connection((parts.hostname, port), timeout=15)
        except OSError as exc:
            self.send_error(502, f"upstream connect failed: {exc}")
            return
        path = parts.path or "/"
        if parts.query:
            path += "?" + parts.query
        req = [f"{self.command} {path} HTTP/1.1"]
        for k, v in self.headers.items():
            if k.lower() in ("proxy-connection", "proxy-authorization"):
                continue
            req.append(f"{k}: {v}")
        req.append("Connection: close")
        upstream.sendall(("\r\n".join(req) + "\r\n\r\n").encode() + body)
        while True:
            chunk = upstream.recv(65536)
            if not chunk:
                break
            self.wfile.write(chunk)
        upstream.close()
        # One exchange per connection. We told the upstream "Connection: close"; the client
        # side closes too, so the handler never blocks waiting for a keep-alive follow-up.
        self.close_connection = True

    do_GET = do_POST = do_PUT = do_DELETE = do_HEAD = do_PATCH = do_OPTIONS = _forward  # type: ignore[assignment]

    @staticmethod
    def _pipe(a: socket.socket, b: socket.socket) -> None:
        sockets = [a, b]
        try:
            while True:
                readable, _, _ = select.select(sockets, [], [], 30)
                if not readable:
                    break
                for s in readable:
                    data = s.recv(65536)
                    if not data:
                        return
                    (b if s is a else a).sendall(data)
        except OSError:
            return
        finally:
            for s in sockets:
                try:
                    s.close()
                except OSError:
                    pass


class _ProxyServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True
    policy: _HostPolicy


class ProxyUnavailable(RuntimeError):
    """The host refused to let the kernel bind a loopback listener.

    Some sandboxes (including the one this package was developed in) forbid listening
    sockets altogether. The runner treats this as *no network for the child*, never as
    "run without the proxy" — see IsolatedRunner.run.
    """


class EgressProxy:
    """A kernel-owned HTTP proxy on loopback that enforces the run's host allowlist."""

    def __init__(self, allowed_hosts: Iterable[str], *, allow_private: bool = False,
                 audit: Callable[..., Any] | None = None, run_id: str = "") -> None:
        self.policy = _HostPolicy(allowed_hosts, allow_private=allow_private, audit=audit,
                                  run_id=run_id)
        try:
            self._server = _ProxyServer(("127.0.0.1", 0), _ProxyHandler)
        except PermissionError as exc:
            raise ProxyUnavailable(
                f"cannot bind a loopback listener for the egress proxy: {exc}") from exc
        self._server.policy = self.policy
        self._thread: threading.Thread | None = None

    @property
    def address(self) -> str:
        host, port = self._server.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> "EgressProxy":
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True,
                                        name="psh-egress-proxy")
        self._thread.start()
        return self

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()

    def __enter__(self) -> "EgressProxy":
        return self.start()

    def __exit__(self, *exc: object) -> None:
        self.stop()

    @property
    def decisions(self) -> list[HostDecision]:
        return list(self.policy.decisions)

    def stats(self) -> dict[str, Any]:
        ds = self.decisions
        return {"decisions": len(ds), "allowed": sum(d.allowed for d in ds),
                "refused": sum(not d.allowed for d in ds)}


class _DeadProxy:
    """Stands in for the proxy when no network is wanted and no listener can be bound.

    Proxy variables point at a closed loopback port, so a proxy-honouring client fails to
    connect to anything. Same limit as the real proxy: a raw socket is not confined.
    """

    address = "http://127.0.0.1:9"
    decisions: list[HostDecision] = []

    def __enter__(self) -> "_DeadProxy":
        return self

    def __exit__(self, *exc: object) -> None:
        pass


# ------------------------------------------------------------ child environment

#: Variables a child may inherit from the kernel when the envelope grants "inherit_locale".
_SAFE_INHERIT = ("PATH", "LANG", "LC_ALL", "TZ", "TMPDIR", "HOME")


def build_child_environment(*, proxy_address: str | None, grants: Mapping[str, str] | None = None,
                            inherit: Sequence[str] = _SAFE_INHERIT,
                            workdir: Path | None = None) -> dict[str, str]:
    """Build a subprocess environment from nothing (Codex ``env_clear`` pattern).

    Nothing is inherited by default except the short safe list. Loader variables
    (``LD_PRELOAD``, ``LD_LIBRARY_PATH``, ``DYLD_*``) can never be inherited because they are
    not in the safe list — there is no scrub step to get wrong. The proxy variables point
    every well-behaved HTTP client at the kernel's proxy; ``no_proxy`` is set empty so an
    inherited exception cannot open a side door.
    """
    env: dict[str, str] = {}
    for key in inherit:
        if key in os.environ and not key.upper().startswith(("LD_", "DYLD_")):
            env[key] = os.environ[key]
    env.setdefault("PATH", "/usr/bin:/bin")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONNOUSERSITE"] = "1"
    if workdir is not None:
        env["HOME"] = str(workdir)
        env["TMPDIR"] = str(workdir)
    if proxy_address:
        for key in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy", "ALL_PROXY"):
            env[key] = proxy_address
        env["NO_PROXY"] = env["no_proxy"] = ""
    for key, value in (grants or {}).items():
        env[str(key)] = str(value)
    return env


# ------------------------------------------------------------- sandbox backend

class SandboxBackend(Protocol):
    """OS-level enforcement: the layer this session cannot install or verify."""

    def wrap(self, argv: Sequence[str], *, workdir: Path, allow_network: bool) -> list[str]:
        """Return an argv that runs ``argv`` inside the sandbox."""
        ...

    def describe(self) -> str:
        ...


class NoSandbox:
    """No OS sandbox. Says so, rather than pretending."""

    def wrap(self, argv: Sequence[str], *, workdir: Path, allow_network: bool) -> list[str]:
        return list(argv)

    def describe(self) -> str:
        return ("no OS sandbox: filesystem and raw-socket access are NOT confined. The egress "
                "proxy governs HTTP clients that honour proxy variables; a raw socket bypasses "
                "it. Install a SandboxBackend (Seatbelt on macOS, bubblewrap+seccomp on Linux) "
                "for physical enforcement.")


# ---------------------------------------------------------------- the runner

@dataclass(frozen=True, slots=True)
class IsolatedResult:
    argv: tuple[str, ...]
    exit_code: int
    stdout: str
    stderr: str
    duration_s: float
    timed_out: bool
    egress_decisions: tuple[HostDecision, ...]
    sandbox: str

    @property
    def ok(self) -> bool:
        return self.exit_code == 0 and not self.timed_out


class IsolatedRunner:
    """Run a command in a subprocess with a clean environment behind the egress proxy."""

    def __init__(self, *, sandbox: SandboxBackend | None = None,
                 audit: Callable[..., Any] | None = None) -> None:
        self.sandbox = sandbox or NoSandbox()
        self._audit = audit
        self.runs = 0

    def run(self, argv: Sequence[str], *, workdir: Path, allowed_hosts: Iterable[str] = (),
            grants: Mapping[str, str] | None = None, timeout_s: float = 120.0,
            memory_mb: int | None = 2048, run_id: str = "", stdin: str | None = None,
            allow_private_hosts: bool = False) -> IsolatedResult:
        workdir = Path(workdir)
        workdir.mkdir(parents=True, exist_ok=True)
        self.runs += 1
        hosts = list(allowed_hosts)
        try:
            proxy_cm: Any = EgressProxy(hosts, allow_private=allow_private_hosts,
                                        audit=self._audit, run_id=run_id)
        except ProxyUnavailable as exc:
            if hosts:
                # The run needs network and the kernel cannot govern it. Refusing is the only
                # honest answer: running unproxied would be the v0.3 bypass with extra steps.
                if self._audit is not None:
                    self._audit("isolated_run_refused", reason="egress proxy unavailable",
                                hosts=len(hosts), run_id=run_id)
                raise
            proxy_cm = _DeadProxy()  # no hosts wanted: point clients at a closed port
        with proxy_cm as proxy:
            env = build_child_environment(proxy_address=proxy.address, grants=grants,
                                          workdir=workdir)
            wrapped = self.sandbox.wrap(argv, workdir=workdir,
                                        allow_network=bool(list(allowed_hosts)))
            started = time.time()
            timed_out = False
            try:
                proc = subprocess.run(
                    wrapped, cwd=str(workdir), env=env, input=stdin, capture_output=True,
                    text=True, timeout=timeout_s,
                    preexec_fn=_preexec(memory_mb) if sys.platform != "win32" else None,
                    start_new_session=True)
                code, out, err = proc.returncode, proc.stdout, proc.stderr
            except subprocess.TimeoutExpired as exc:
                timed_out = True
                code = 124
                out = (exc.stdout or b"").decode(errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
                err = (exc.stderr or b"").decode(errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
            duration = time.time() - started
            result = IsolatedResult(
                argv=tuple(argv), exit_code=code, stdout=out[:200_000], stderr=err[:50_000],
                duration_s=duration, timed_out=timed_out,
                egress_decisions=tuple(proxy.decisions), sandbox=type(self.sandbox).__name__)
        if self._audit is not None:
            self._audit("isolated_run", argv0=argv[0] if argv else "", exit_code=code,
                        timed_out=timed_out, duration_s=round(duration, 3),
                        egress_allowed=sum(d.allowed for d in result.egress_decisions),
                        egress_refused=sum(not d.allowed for d in result.egress_decisions),
                        sandbox=result.sandbox, run_id=run_id)
        return result


def _preexec(memory_mb: int | None) -> Callable[[], None]:
    def fn() -> None:
        try:
            import resource

            # No core dumps (Codex process-hardening).
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            if memory_mb:
                limit = memory_mb * 1024 * 1024
                for name in ("RLIMIT_AS", "RLIMIT_DATA"):
                    try:
                        resource.setrlimit(getattr(resource, name), (limit, limit))
                        break
                    except (ValueError, OSError, AttributeError):
                        continue
        except Exception:  # noqa: BLE001 - hardening is best-effort per platform
            pass
    return fn
