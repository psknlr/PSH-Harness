# psh — Physician-Scientist Harness

A governed control plane for physician-scientist work. Not a bigger agent: the layer your
agents, tools and harnesses run *through*.

## v0.4 — self-audit closure and borrowed enforcement

Nine of eleven self-audited defects closed as tests (two are architectural and stated as open).
Six enforcement patterns adopted from Codex (read from source) and Claude Code (read from official
docs), with per-pattern attribution in `PATTERN_ATTRIBUTION.md`: declarative self-testing
execution policy, approval-to-rule amendments, absolute-deny evaluation order, the shared hook
JSON protocol, default-deny child environments, and a kernel-owned egress proxy that refuses
private ranges even when allowlisted. Tool execution is now process-isolated; kernel-internal code
still is not — `SandboxBackend` is the seam for the OS layer.

Run tests: `PYTHONPATH=src:../sable_pkg/src python -m pytest tests/ -q` (170 pass; 2 end-to-end
proxy tests need a bindable loopback listener and skip where the host forbids one).

## v0.2 — invariant closure

Sixteen defects found in v0.1 by external review are closed as code-level invariants, each
verified by re-running the script that first confirmed it open. The defects shared one shape:
the governed path enforced the property while an ungoverned path reached the same sink.

The seven invariants:

1. **Mandatory ingress** — no value reaches a gateway unclassified, and a caller-supplied
   label is re-validated, never trusted. A label can be raised, never lowered.
2. **Deep labelling** — a container's label is the join of every descendant; a walk that hits
   its budget escalates rather than reporting clean.
3. **One authority predicate** — `AuthorityLattice` covers 16 dimensions behind `restrict`,
   delegation and subagent creation.
4. **Release before exposure** — output is quarantined; `released_output` is `None` unless
   the gate passed.
5. **Classified persistence** — every durable write carries principal, source run and
   validation status, classified at the boundary.
6. **Evidence has provenance** — retrieving capability, run, content hash, retraction status;
   spans located by offset, not quoted by a model.
7. **Real accounting** — token and cost ceilings fed by actual usage, estimates flagged.

## Install

```bash
pip install -e ./psh_pkg -e ./sable_pkg      # composed
pip install -e ./psh_pkg                     # standalone; classification degrades and says so
```

Run tests with `PYTHONPATH=sable_pkg/src:psh_pkg/src` — editable installs may not survive a
session restart.

## Use

```python
from psh import get_profile
from psh.kernel import TrustedKernel
from psh.runtime import Runner

policy = get_profile("clinical_research").freeze()   # local only, PHI ceiling
kernel = TrustedKernel(policy=policy)
runner = Runner(kernel, model=local_model, model_invoke=my_provider, policy=policy)

result = runner.run("Summarise the HFpEF evidence", sources={"34449189": abstract})
if result.released_output is None:
    print("refused:", result.error, "| quarantined as", result.quarantine_ref)
```

`clinical_research` is deliberately unusable without a local model. That is the profile
working as intended.

## Scope

Research prototype. Not clinical-safe, not production-ready. No sandboxing, so the broker is
a *logical* governance boundary. Classification is a safety net rather than certified
de-identification; claim support is lexical; the audit chain is tamper-evident, not
tamper-proof; the planner is a placeholder.

See `PSH_V2_INVARIANT_REPORT.md`. MIT licensed.
